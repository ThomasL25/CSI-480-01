Progress Check #1
5/6 filter complete
File Uploading working

Website:
https://keen-mandazi-6bcb0b.netlify.app/
